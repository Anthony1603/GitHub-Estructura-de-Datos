﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Declaracion de Variables
            int[,] matriz = new int[3, 3];
            int valor = 1;
            int Suma = 0;
            int Opcion = 0;

            //Titulo del Programa
            Console.WriteLine("***Suma de Matriz***");

            //Condicional Para Ver la Suma en X o en Cruz
            Console.WriteLine("Seleccione una de las opciones:\n1.Ver la suma en X de la matriz\n2.Ver la suma en cruz de la matriz");
            Opcion = int.Parse(Console.ReadLine());

            if (Opcion == 1)
            {
                //Procedimiento Suma en X de Matriz 
                for (int f = 0; f < 3; f++)
                {
                    for (int c = 0; c < 3; c++)
                    {
                        matriz[f, c] = valor++;
                        if ((c == f) || (c == 0) && (f == 2) || (f == 0) && (c == 2))
                        {
                            Suma += matriz[f, c];
                        }

                    }
                    Console.WriteLine();
                }

                for (int i = 0; i < 3; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        Console.Write($"   {matriz[i, j]}");
                    }
                    Console.WriteLine();
                }
                Console.Write($"\nLa suma en X de los numeros de la matriz es {Suma}\n");
            }
            else if (Opcion == 2)
            {
                //Procedimiento Suma en + de Matriz
                for (int f = 0; f < 3; f++)
                {
                    for (int c = 0; c < 3; c++)
                    {
                        matriz[f, c] = valor++;
                        if ((f == 1) || (c == 1))
                        {
                            Suma += matriz[f, c];
                        }

                    }
                    Console.WriteLine();
                }

                for (int i = 0; i < 3; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        Console.Write($"   {matriz[i, j]}");
                    }
                    Console.WriteLine();
                }
                Console.Write($"\nLa suma en X de los numeros de la matriz es {Suma}\n");
            }

            //Finalizacion del Programa
            Console.WriteLine("Presione cualquier tecla para finalizar");
            Console.ReadKey();
            Environment.Exit(0);

        }
    }
}
